===========
TweetsAlbum
===========

TweetsAlbum enables users to download specific images from Twitter
and then creates an album for every different hashtag. Typical usage
often looks like this::

    ./python twitter.py #carnival 20


    
A Section
=========

Etc...